import tkinter as tk

# ---------- WINDOW ----------
root = tk.Tk()
root.title("🌍 GPS Navigator - User Input")

# ---------- CONFIG ----------
GRID = 5
CELL = 60

# ---------- DATA ----------
city = [[0]*GRID for _ in range(GRID)]
row = 0
col = 0
city[row][col] = 1

# ---------- CANVAS ----------
canvas = tk.Canvas(root, width=GRID*CELL+40, height=GRID*CELL+40, bg="#1e1e1e")
canvas.pack(pady=10)

# ---------- DRAW FUNCTION ----------
def draw():
    canvas.delete("all")
    for r in range(GRID):
        for c in range(GRID):
            x1 = c*CELL + 20
            y1 = r*CELL + 20
            x2 = x1 + CELL
            y2 = y1 + CELL

            if r == 0 and c == 0:
                color = "#2196f3"      # Start
            elif city[r][c] == 1:
                color = "#4caf50"      # Path
            else:
                color = "#eeeeee"      # Empty

            canvas.create_rectangle(x1, y1, x2, y2, fill=color, outline="#333", width=2)
            canvas.create_text(x1+30, y1+30, text=f"{r},{c}", font=("Arial", 9, "bold"))

# ---------- MOVE ----------
def move():
    global row, col
    d = entry.get().strip().capitalize()

    if d == "East" and col + 1 < GRID:
        col += 1
    elif d == "West" and col - 1 >= 0:
        col -= 1
    elif d == "South" and row + 1 < GRID:
        row += 1

    elif d == "North" and row - 1 >= 0:
        row -= 1

    city[row][col] = 1
    entry.delete(0, tk.END)
    draw()

# ---------- INPUT ----------
frame = tk.Frame(root)
frame.pack()

tk.Label(frame, text="Enter Direction (North/South/East/West):").pack(side="left")
entry = tk.Entry(frame, width=12)
entry.pack(side="left", padx=5)

tk.Button(frame, text="Move", command=move).pack(side="left", padx=5)

# ---------- START ----------
draw()
root.mainloop()
