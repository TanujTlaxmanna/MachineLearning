import tkinter as tk

# ---------- CONFIG ----------
GRID = 5
CELL = 60

# ---------- DATA ----------
city = [[0]*GRID for _ in range(GRID)]
row = 0
col = 0
steps = 0
city[row][col] = 1

# ---------- WINDOW ----------
root = tk.Tk()
root.title("🚗 Dynamic GPS Navigator")

canvas = tk.Canvas(root, width=GRID*CELL+40, height=GRID*CELL+40, bg="#1c1c1c")
canvas.pack(pady=10)

status = tk.Label(root, text="Steps: 0", font=("Arial", 11, "bold"))
status.pack()

# ---------- DRAW ----------
def draw():
    canvas.delete("all")
    for r in range(GRID):
        for c in range(GRID):
            x1 = c*CELL + 20
            y1 = r*CELL + 20
            x2 = x1 + CELL
            y2 = y1 + CELL

            if r == row and c == col:
                color = "#e53935"      # Current position (Red)
            elif r == 0 and c == 0:
                color = "#1e88e5"      # Start (Blue)
            elif city[r][c] == 1:
                color = "#43a047"      # Path (Green)
            else:
                color = "#eeeeee"

            canvas.create_rectangle(x1, y1, x2, y2, fill=color, outline="#333", width=2)
            canvas.create_text(x1+30, y1+30, text=f"{r},{c}", font=("Arial", 9, "bold"))

# ---------- MOVE ----------
def move():
    global row, col, steps
    data = entry.get().split()

    for d in data:
        if d == "1" and row > 0:
            row -= 1
        elif d == "2" and row < GRID-1:
            row += 1
        elif d == "3" and col < GRID-1:
            col += 1
        elif d == "4" and col > 0:
            col -= 1

        city[row][col] = 1
        steps += 1

    entry.delete(0, tk.END)
    status.config(text=f"Steps: {steps}")
    draw()

# ---------- RESET ----------
def reset():
    global city, row, col, steps
    city = [[0]*GRID for _ in range(GRID)]
    row = col = steps = 0
    city[row][col] = 1
    status.config(text="Steps: 0")
    draw()

# ---------- CONTROLS ----------
tk.Label(
    root,
    text="1=North  2=South  3=East  4=West (space separated)",
    font=("Arial", 10)
).pack()

frame = tk.Frame(root)
frame.pack(pady=5)

entry = tk.Entry(frame, width=20, font=("Arial", 12))
entry.pack(side="left", padx=5)

tk.Button(frame, text="Move", command=move).pack(side="left", padx=5)
tk.Button(frame, text="Reset", command=reset).pack(side="left", padx=5)

draw()
root.mainloop()

